
/* 
 * File:   usart9600
 * Author: Carlos Gil 
 * Comments: Funcion para inicializar la configuracion USART del OIC16F887
 * Revision history: 
 */

 
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> 

void initUSART(void);

#endif	/* XC_HEADER_TEMPLATE_H */

